#include "d3d9_device.h"

namespace dxvk {

  D3D9Multithread::D3D9Multithread(
          BOOL                  Protected)
    : m_protected( Protected ) { }

}